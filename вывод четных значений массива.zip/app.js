const array = [1, 2, 3, 4, 5]

    let result = array.filter (elem => elem % 2 == 0);
    


console.log(result); 
