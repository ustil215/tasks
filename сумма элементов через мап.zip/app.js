const array = [1, 2, 3, 4, 5]

const arrTrue = (arr) => {
    let sum = 0;

    arr.map(elem => {
        sum++;
    }); 

    return sum;
}
console.log(arrTrue(array)); 
