const array = [1, 2, 3, 4, 5]

const arrTrue = (array) => {
    array.forEach(elem => {
        if (elem > 0){
            console.log('Правда');
        } else {
            console.log('Ложь');
        }
     })
     return arrTrue;
}
arrTrue(array);
