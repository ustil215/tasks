const array = [1, 2, 3, 4, 5]

testFunction = (arr, val) => {
    arr.forEach(elem => {
        if (elem === val) {
            console.log('Правда');
        } else {
            console.log('Ложь');
        }
    })
}


const t = testFunction(array, 5);
