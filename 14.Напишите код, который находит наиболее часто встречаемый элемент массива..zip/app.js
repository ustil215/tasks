const arr = [1,2,3,4,5,6,3,2,4];
let newStr = arr.join('');
console.log(newStr);  //123456324

function maxCount(arr){
  const obj = {};
  for(let i = 0 ; i < arr.length; i++){
    const key = arr[i];
      if(obj[key]){
          obj[key]++
      }else {
          obj[key] = 1;
      }
  }

  let maxCount = 0 ;
  let maxString = "";
  for(let key in obj){
      if(maxCount < obj[key]){
          maxCount = obj[key];
          maxString = key;
      }
  }
  return 'Самая частая цифра:' + maxString + 'появилось' + maxCount + 'раз';
}

var a = maxCount(arr);
console.log(a);