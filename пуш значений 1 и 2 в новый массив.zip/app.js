let arrow = [5, 1, 2, 19, 80, 505, 8, 7, 3, 101, 590, 46464646];


testFunction = (arr, val, val2) => {
    let result = [];

    arrow.forEach(value => {
      if(value > val && value > val2) {
        result.push(value)
      }
    })
    return result;
  };

const t = testFunction(arrow, 2, 1);
console.log(t);