const arrow = [1, 2, 3, 4, 5, 6]

let result2 = arrow.filter(function(elem) {
    return elem %2  ===  0;
});

console.log(result2);

let result = arrow.filter(function(elem) {
    return elem %2  ===  1;
});

console.log(result);

