const arrow = [1, 2, 5, 4, 5, 6, 7, 5, 9, 10, 11, 12, 13, 5];

const testFunction = (arr, value) => {
    let newArrow = [];
    let number = 0;
  
    arr.forEach((element, index) => {
      if(element === value) {
        number = index;
        newArrow.push(number)
      }    
    });
  
    return newArrow;
  };

const resolt = testFunction(arrow, 5)
console.log("resolt", resolt);