let array = [
    {
      name: 'test',
      age: 9
    },
    {
      name: 'west',
      age: 50
    },
    {
      name: 'rest',
      age: 11
    },
    {
      name: 'test',
      age: 30
    }
  ];


testFunction = (arr, val,val2) => {
    let result = [];

    arr.forEach(value => {
        if (value.name === val || value.age >= val2) {
            result.push(value)
        }
    })
    return result
}


const t = testFunction(array, 'test', 9);
console.log(t);