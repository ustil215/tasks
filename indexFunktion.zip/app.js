const arrow = [1, 2, 5, 4, 5, 6, 7, 5, 9, 10, 11, 12, 130, 11, 280];

indexFunction = (arr)  => {
    let max = 0;
  
    arr.forEach(value => {
      if (value > max) {
        max = value;
      }
    });
  
    return max;
}

console.log(indexFunction(arrow));
