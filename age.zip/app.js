let arrow = [
  {
    name: 'test',
    age: 9,
    country: 'RF'
  },
  {
    name: 'west',
    age: 50,
    country: 'RF'
  },
  {
    name: 'rest',
    age: 89,
    country: 'RF'
  },
  {
    name: 'test',
    age: 30,
    country: 'RF'
  },{
    name: 'mest',
    age: 40,
    country: 'RF'
  }
];


maxFunction = (arr)  => {
    let max = arr[1];
  
    arr.forEach(value => {
      if (value.age > max.age) {
        max = value;
      }
    })
  
    return max;
  }
  
  console.log(maxFunction(arrow));
  