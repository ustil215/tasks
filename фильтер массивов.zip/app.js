let arr = [5, 1, 2, 19, 80, 505, 8, 7, 3, 101, 590, 46464646];
let arr2 = [5, 1, 2, 189, 80, 1505, 8, 7, 3, 10, 592, 4646];
let arr3 = [5, 777];


const newArr = (arr, arr2, arr3) => {
    let array = [...arr, ...arr2, ...arr3];
    const set = new Set(array);

    return set;
}

console.log(newArr(arr, arr2, arr3));

